
import json
from flask import Flask, render_template, request
import llama  # ou o nome da biblioteca que você está usando para o LLaMA

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def process():
    # Recebe o texto do frontend
    data = request.get_json()
    text = data['text']
    
    # Aqui você processa o texto com o LLaMA (substitua pelo código real)
    result = llama.process_text(text)
    
    # Retorna o resultado para o frontend
    return json.dumps({'result': result})

if __name__ == "__main__":
    app.run(debug=True)
