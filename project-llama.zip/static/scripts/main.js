
document.getElementById('form').addEventListener('submit', async function(event) {
    event.preventDefault();
    
    const text = document.getElementById('text').value;
    const resultDiv = document.getElementById('result');

    const response = await fetch('/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: text })
    });

    const data = await response.json();
    resultDiv.innerHTML = `<h3>Resultado do LLaMA:</h3><pre>${data.result}</pre>`;
});
